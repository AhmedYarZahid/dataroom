<?php
return [
    'adminEmail' => 'xxxxxxxxx@xxxxxxxxx',
    'supportEmail' => 'xxxxxxxxx@xxxxxxxxx',
    'user.passwordResetTokenExpire' => 3600,

    'mail' => array(
        'adminEmail' => ['xxxxxxxxx@xxxxxxxxx', 'xxxxxxxxx@xxxxxxxxx', 'xxxxxxxxx@xxxxxxxxx'],
        'adminName' => 'Admin',
        'replyToEmail' => 'xxxxxxxxx@xxxxxxxxx',
        'contactEmail' => 'xxxxxxxxx@xxxxxxxxx'
        //'senderEmail' => 'xxxxxxxxx@xxxxxxxxx',
    ),

    'userLogoWidth' => 300,
    'userLogoHeight' => 300,

    'GOOGLE_API_KEY' => 'xxxxxxxxx',
];
