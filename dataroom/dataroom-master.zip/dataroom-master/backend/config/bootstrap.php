<?php

/*Yii::setAlias('@uploads', dirname(dirname(__DIR__)) . '/uploads');
Yii::setAlias('uploads/images-rel', '/uploads/images');
Yii::setAlias('uploads/editor-rel', '/uploads/editor');*/