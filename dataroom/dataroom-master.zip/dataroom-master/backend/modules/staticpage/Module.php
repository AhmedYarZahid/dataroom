<?php

namespace backend\modules\staticpage;

class Module extends \yii\base\Module
{
    public $controllerNamespace = 'app\modules\staticpage\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
