<?php

namespace app\modules\supervisormanager\components\supervisor\exceptions;


class ProcessConfigException extends \Exception
{

}