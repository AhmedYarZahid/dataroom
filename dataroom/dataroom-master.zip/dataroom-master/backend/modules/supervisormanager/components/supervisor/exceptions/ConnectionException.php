<?php

namespace app\modules\supervisormanager\components\supervisor\exceptions;

class ConnectionException extends \Exception
{

}