<?php

namespace app\modules\supervisormanager\components\supervisor\exceptions;


class AuthenticationException extends \Exception
{

}