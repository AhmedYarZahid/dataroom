<?php

namespace app\modules\supervisormanager\components\supervisor\exceptions;


class SupervisorException extends \Exception
{

}