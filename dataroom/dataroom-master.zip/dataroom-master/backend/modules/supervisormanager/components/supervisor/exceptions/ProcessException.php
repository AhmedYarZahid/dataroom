<?php

namespace app\modules\supervisormanager\components\supervisor\exceptions;

class ProcessException extends \Exception
{

}