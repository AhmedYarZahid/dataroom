<?php

namespace backend\modules\faq;

class Module extends \yii\base\Module
{
    public $controllerNamespace = 'backend\modules\faq\controllers';

    public function init()
    {
        parent::init();
    }
}
