<?php

namespace backend\modules\notify;

class Module extends \yii\base\Module
{
    public $controllerNamespace = 'backend\modules\notify\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
