<br>
Pour vous désinscrire et ne plus recevoir nos communications cliquez ici : <a href="{{var:unsubscribeLink:'#'}}">Désinscrire</a>
</body>
</html>