<!DOCTYPE html>
<html lang='<?= Yii::$app->language; ?>'>
<head>
    <meta charset='<?= Yii::$app->charset; ?>' />
</head>
<body>