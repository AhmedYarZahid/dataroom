<?php

namespace backend\modules\metatags;

class Module extends \yii\base\Module
{
    public $controllerNamespace = 'app\modules\metatags\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
