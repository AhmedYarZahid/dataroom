<?php

namespace backend\modules\contact;

class Module extends \yii\base\Module
{
    public $controllerNamespace = 'backend\modules\contact\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
