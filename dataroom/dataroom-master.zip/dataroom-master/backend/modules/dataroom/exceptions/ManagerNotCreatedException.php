<?php

namespace backend\modules\dataroom\exceptions;

use Exception;

class ManagerNotCreatedException extends Exception
{

}