<script id="header-preview" type="text/mustache">
    <div class="tp-content-block header {{blockSettings.classList}}">
        <img class="bg-image" src="{{content.src}}" />
        <p class="heading-text">{{content.title}}</p>
    </div>
</script>