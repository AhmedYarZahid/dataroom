<?php

namespace backend\modules\comments;

class Module extends \yii\base\Module
{
    public $controllerNamespace = 'app\modules\comments\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
