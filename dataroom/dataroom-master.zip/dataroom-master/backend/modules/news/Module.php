<?php

namespace backend\modules\news;

class Module extends \yii\base\Module
{
    public $controllerNamespace = 'app\modules\news\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
