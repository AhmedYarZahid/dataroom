<?php
/* @var $this yii\web\View */

$this->title = Yii::$app->name  . ' - Dashboard';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1><?= Yii::t('admin', 'Welcome to admin panel!') ?></h1>
    </div>

</div>
